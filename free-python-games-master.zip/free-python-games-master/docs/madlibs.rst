Mad Libs
========

Create a funny story from a not-so funny story

.. literalinclude:: ../freegames/madlibs.py
